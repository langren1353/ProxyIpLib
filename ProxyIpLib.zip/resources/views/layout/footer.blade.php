<div class="content-footer">
    <div class="footer-cnzz">
        <em>Copyright © 2019 高可用全球免费代理IP库</em>
        <script type="text/javascript">document.write(unescape("%3Cspan id='cnzz_stat_icon_1279260261'%3E%3C/span%3E%3Cscript src='https://v1.cnzz.com/z_stat.php%3Fid%3D1279260261%26online%3D1%26show%3Dline' type='text/javascript'%3E%3C/script%3E"));</script>
        <span>&nbsp;&nbsp;<a href="{{ route('sitemap.html') }}">站点地图</a> </span>
    </div>
</div>
<!-- 360 自动收录推送 -->
<script>
    // (function () {
    //     var src = "https://jspassport.ssl.qhimg.com/11.0.1.js?d182b3f28525f2db83acfaaf6e696dba";
    //     document.write('<script src="' + src + '" id="sozz"><\/script>');
    // })();
</script>